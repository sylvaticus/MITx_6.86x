X = load('p1_b_X.dat');
y = load('p1_b_y.dat');
fprintf('Have loaded "X" and "y".\n');
