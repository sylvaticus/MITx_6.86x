X = load('p1_a_X.dat');
y = load('p1_a_y.dat');
fprintf('Have loaded "X" and "y".\n');
