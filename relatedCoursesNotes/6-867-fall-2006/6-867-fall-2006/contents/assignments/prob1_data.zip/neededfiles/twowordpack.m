function idx=twowordpack(word1,word2)
  idx = word1 * 20000 + word2;
